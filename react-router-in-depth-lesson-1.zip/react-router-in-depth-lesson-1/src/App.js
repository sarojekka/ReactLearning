function App() {
  return (
    <div className="App">
      Hello, Ninjas!
    </div>
  );
}

export default App
